import 'package:flutter/material.dart';

void main() {
  runApp(MovieApp());
}

class MovieApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Movie Mania',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final List<String> popularMovies = [
    'Avengers: Endgame (2019)',
    'Joker (2019)',
    'Frozen II (2019)',
    'Spider-Man: No Way Home (2021)',
    'Black Panther: Wakanda Forever (2022)',
    'The Lion King (2019)',
  ];

  final List<String> topRatedMovies = [
    'The Shawshank Redemption (1994)',
    'The Godfather (1972)',
    'The Dark Knight (2008)',
    'Pulp Fiction (1994)',
    'Schindler\'s List (1993)',
    '12 Angry Men (1957)',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Movie Mania'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _buildCategorySection(
              context,
              'Popular Movies',
              popularMovies,
            ),
            SizedBox(height: 20),
            _buildCategorySection(
              context,
              'Top Rated Movies',
              topRatedMovies,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategorySection(
      BuildContext context, String title, List<String> movies) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MovieDetailScreen(
                      title: title,
                      movies: movies,
                    ),
                  ),
                );
              },
              child: Text('More'),
            ),
          ],
        ),
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: movies.sublist(0, 2).map((title) =>
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: MovieCard(title: title),
                    ),
                  )
              ).toList(),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: movies.sublist(2, 4).map((title) =>
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: MovieCard(title: title),
                    ),
                  )
              ).toList(),
            ),
          ],
        ),
      ],
    );
  }
}

class MovieCard extends StatelessWidget {
  final String title;

  MovieCard({required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

class MovieDetailScreen extends StatelessWidget {
  final String title;
  final List<String> movies;

  MovieDetailScreen({required this.title, required this.movies});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: ListView.builder(
        itemCount: movies.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(movies[index]),
          );
        },
      ),
    );
  }
}
