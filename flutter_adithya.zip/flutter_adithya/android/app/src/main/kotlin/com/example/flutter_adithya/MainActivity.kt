package com.example.flutter_adithya

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
